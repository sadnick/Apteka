﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pharm
{
    class Program
    {
        static void Main(string[] args)
        {
            Pharmacy App1 = new Pharmacy();
           
            App1.NamePharm("АптекаPlus");
            App1.lekarctvo("Парацетамол", 80);
            App1.lekarctvo("Финалгон", 310);
            App1.lekarctvo("Гексорал", 180);
            App1.lekarctvo("Гриппферон", 460);
            App1.lekarctvo("Аскорбиновая кислота", 18);
            App1.lekarctvo("Виброцил", 210);

            App1.GetInfo(); // информация об аптеке.
            App1.GetExp(); // самое дорогое лекарство.
            App1.GetSum(); // сумма всех лекарств.

        }
    }
}
