﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pharm
{
    class Pharmacy
    {
        private string nameAptek;

        List<string> name = new List<string>();
        List<double> coast = new List<double>();
        public string NamePharm(string name)
        {
            nameAptek = name;
            return nameAptek;
        }

        public void lekarctvo(string name, double coast)
        {
            this.name.Add(name);
            this.coast.Add(coast);
        }

        public void GetInfo()
        {
            Console.WriteLine($"Название аптеки \"{nameAptek}\"");
            for (int i = 0; i < name.Count; i++)
            {
                Console.Write($"Название лекарства - {name[i]} | ");
                Console.WriteLine($"цена - {coast[i]}р.");
            }
        }
        public void GetSum()
        {
            double sum = 0;
            for (int i = 0; i < coast.Count; i++)
            {
                sum += coast[i];
            }
            Console.WriteLine($"Сумма всех лекарств - {sum}р.");
        }
        public void GetExp()
        {
            double exp = 0;
            int count = 0;
            for (int i = 0; i < coast.Count; i++)
            {
                if (coast[i] > exp)
                {
                    exp = coast[i];
                    count = i;
                }

            }
            Console.WriteLine($"Самое дорогое лекарство {name[count]} стоит {coast[count]}р.");
            Console.ReadKey();
        }
    }
}
